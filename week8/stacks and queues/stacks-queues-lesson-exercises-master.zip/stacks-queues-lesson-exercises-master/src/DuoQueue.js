/* Write your class below */








//You can paste the test code from the lesson below to test your solution




/* Do not remove the exports below */
module.exports = DuoQueue