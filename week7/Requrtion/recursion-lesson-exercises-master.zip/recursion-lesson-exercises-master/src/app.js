/*
  Write your code in the corresponding method
  Please note: You must also add the correct arguments to the methods
*/

//Exercise 1
const findFactorial = function() {
  //Your code here

}

//Exercise 2
const reverseString = function() {
  //Your code here

}

//Exercise 3
const arr1 = [1, 2, 3]
const arr2 = []

const swap = function() {
  //Your code here

}

/* DO NOT REMOVE THE EXPORTS BELOW */
module.exports = { findFactorial, reverseString, swap }