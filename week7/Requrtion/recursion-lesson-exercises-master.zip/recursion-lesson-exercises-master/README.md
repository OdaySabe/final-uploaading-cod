Make sure to change the `name` inside the `package.json`!
And **fork** this repo, not clone!
